import json
import os
import random
import time
import uuid
from fakeyou import FakeYou
import requests
from pydub import AudioSegment
import numpy as np
import librosa

# Kanye
artist_token = "TM:1a7mjjxwq4js"
# Snoop
# artist_token = "TM:hqcecn351tpc"

fakeyou = FakeYou()

def get_track(lyrics_path: str):
    rap_filename = str(uuid.uuid4())
    rap: AudioSegment = get_rap(lyrics_path=lyrics_path)
    beat1: AudioSegment = AudioSegment.from_file("C:\\Users\\Schneider David\\Downloads\\_Good Feeling_ Kanye West (Type Beat).mp3")
    beat2: AudioSegment = AudioSegment.from_file("C:\\Users\\Schneider David\\Downloads\\[FREE] KANYE WEST TYPE BEAT _FREE_ FT J COLE.mp3")

    id = uuid.uuid4()
    os.mkdir(str(id))
    track1 = beat1.overlay(seg=rap, position=23580)
    track2 = beat2.overlay(seg=rap, position=21700)
    track1.export(f"{id}\\good_feeling_{id}.mp3")
    track2.export(f"{id}\\set_me_free_{id}.mp3")

    rap.export(f"{id}\\rap_{id}.mp3")

def get_rap(lyrics_path: str):
    rap_segments = get_rap_segments(lyrics_path=lyrics_path)
    rap = AudioSegment.empty()
    for i in range(0, len(rap_segments)):
        rap += rap_segments[i][0:rap_segments[i].__len__()-500]
    return rap

def get_rap_segments(lyrics_path: str):
    job_tokens = []
    text_segments = get_text_segments(lyrics_path=lyrics_path)
    for text_segment in text_segments:
        while True:
            try:
                print("Job request made")
                job_token = fakeyou.make_tts_job(text=text_segment, ttsModelToken=artist_token)
                job_tokens.append(job_token)
                print("Job request successful")
                break
            except:
                print("Job request failed")
                time.sleep(5)

    jobs = []
    for job_token in job_tokens:
        job = fakeyou.tts_poll(job_token)
        jobs.append(job)
        print("Job detected")

    audio_segments = []
    for job in jobs:
        response = requests.get(job.link)
        split = response.url.split("/")
        filename = "raw\\" + split[split.__len__() - 1]
        with open(filename, "wb") as f:
            f.write(response.content)
        audio_segment = AudioSegment.from_file(filename)
        audio_segments.append(audio_segment)
        print("Job downloaded")

    return audio_segments

def get_text_segments(lyrics_path: str):
    text_split = []
    with open(lyrics_path, "r") as f:
        text_split = f.readlines()  
    text_segments = []
    current_text = ""
    for line in text_split:
        if line == "\n":
            text_segments.append(current_text)
            current_text = ""
        else:
            current_text += line.replace("\n", "")
    text_segments.append(current_text)
    return text_segments

get_track("text.txt")